// about-section.js - Componente de sección Sobre Nosotros para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal de la sección Sobre Nosotros
export function AboutSection() {
  // Animaciones para los elementos
  const controls = useAnimation()
  
  // Efecto para detectar cuando la sección es visible
  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('about')
      if (element) {
        const rect = element.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom >= 0
        
        if (isVisible) {
          controls.start({
            opacity: 1,
            y: 0,
            transition: { duration: 0.8, staggerChildren: 0.2 }
          })
        }
      }
    }
    
    window.addEventListener('scroll', handleScroll)
    // Trigger once on mount
    handleScroll()
    
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])
  
  return (
    <Frame
      name="AboutSection"
      id="about"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "50px",
          textAlign: "center",
          opacity: 0,
          y: 20
        }}
        animate={controls}
      >
        Sobre WAI Agents
      </Frame>

      <Frame
        name="AboutContent"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          gap: "50px",
          maxWidth: "1200px",
          "@media (max-width: 992px)": {
            flexDirection: "column"
          }
        }}
      >
        {/* Imagen o gráfico */}
        <Frame
          name="AboutImage"
          background={{
            type: "gradient",
            gradient: {
              angle: 135,
              stops: [
                { position: 0, color: colors.primaryButton },
                { position: 100, color: colors.secondaryButton }
              ]
            }
          }}
          width="45%"
          height={400}
          radius={20}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            overflow: "hidden",
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)",
            opacity: 0,
            x: -50,
            "@media (max-width: 992px)": {
              width: "100%",
              height: 300
            }
          }}
          animate={controls}
        >
          {/* Gráfico de IA */}
          <Frame
            name="AIGraphic"
            background="transparent"
            width="80%"
            height="80%"
            style={{
              position: "relative"
            }}
          >
            {/* Cerebro digital (representación abstracta) */}
            <svg width="100%" height="100%" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="100" cy="100" r="80" fill="rgba(255,255,255,0.1)" />
              <circle cx="100" cy="100" r="60" fill="rgba(255,255,255,0.05)" stroke="rgba(255,255,255,0.2)" strokeWidth="1" />
              
              {/* Nodos */}
              <circle cx="100" cy="60" r="8" fill="white" />
              <circle cx="70" cy="90" r="6" fill="white" />
              <circle cx="130" cy="90" r="6" fill="white" />
              <circle cx="80" cy="130" r="7" fill="white" />
              <circle cx="120" cy="130" r="7" fill="white" />
              <circle cx="100" cy="150" r="5" fill="white" />
              
              {/* Conexiones */}
              <line x1="100" y1="60" x2="70" y2="90" stroke="white" strokeWidth="1" />
              <line x1="100" y1="60" x2="130" y2="90" stroke="white" strokeWidth="1" />
              <line x1="70" y1="90" x2="80" y2="130" stroke="white" strokeWidth="1" />
              <line x1="130" y1="90" x2="120" y2="130" stroke="white" strokeWidth="1" />
              <line x1="80" y1="130" x2="100" y2="150" stroke="white" strokeWidth="1" />
              <line x1="120" y1="130" x2="100" y2="150" stroke="white" strokeWidth="1" />
              <line x1="70" y1="90" x2="130" y2="90" stroke="white" strokeWidth="1" strokeDasharray="4 2" />
              <line x1="80" y1="130" x2="120" y2="130" stroke="white" strokeWidth="1" strokeDasharray="4 2" />
              
              {/* Pulsos animados */}
              <circle cx="100" cy="60" r="12" stroke="white" strokeWidth="1" opacity="0.5">
                <animate attributeName="r" values="8;20;8" dur="3s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.5;0;0.5" dur="3s" repeatCount="indefinite" />
              </circle>
              <circle cx="80" cy="130" r="10" stroke="white" strokeWidth="1" opacity="0.5">
                <animate attributeName="r" values="7;15;7" dur="4s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.5;0;0.5" dur="4s" repeatCount="indefinite" />
              </circle>
              <circle cx="120" cy="130" r="10" stroke="white" strokeWidth="1" opacity="0.5">
                <animate attributeName="r" values="7;15;7" dur="3.5s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.5;0;0.5" dur="3.5s" repeatCount="indefinite" />
              </circle>
            </svg>
          </Frame>
        </Frame>

        {/* Texto descriptivo */}
        <Frame
          name="AboutText"
          background="transparent"
          width="45%"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "20px",
            opacity: 0,
            x: 50,
            "@media (max-width: 992px)": {
              width: "100%"
            }
          }}
          animate={controls}
        >
          <Frame
            name="AboutDescription"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              lineHeight: 1.6,
              color: colors.primaryText
            }}
          >
            WAI Agents es una empresa especializada en automatización de procesos mediante inteligencia artificial. Ofrecemos soluciones personalizadas para 12 sectores empresariales diferentes, transformando la manera en que las empresas gestionan su atención al cliente y sus operaciones diarias.
          </Frame>
          <Frame
            name="AboutDescription2"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              lineHeight: 1.6,
              color: colors.primaryText
            }}
          >
            Nuestra misión es simple: automatizar TODO. Con nuestros agentes inteligentes, garantizamos que todo fluya sin errores, sin excusas y sin estrés, permitiéndote enfocarte en lo que realmente importa para tu negocio.
          </Frame>
          <Frame
            name="AboutHighlight"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "20px",
              fontWeight: 600,
              color: colors.secondaryText,
              marginTop: "10px"
            }}
          >
            Se acabaron los pendientes. Con WAI Agents, la automatización inteligente está al alcance de tu mano.
          </Frame>
          
          {/* Características clave */}
          <Frame
            name="KeyFeatures"
            background="transparent"
            width="100%"
            height="auto"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "15px",
              marginTop: "20px"
            }}
          >
            <KeyFeature 
              text="Automatización de atención al cliente 24/7" 
              icon="customer-service"
            />
            <KeyFeature 
              text="Integración con tus sistemas existentes" 
              icon="integration"
            />
            <KeyFeature 
              text="Soluciones personalizadas por sector" 
              icon="customize"
            />
            <KeyFeature 
              text="Implementación rápida en solo 4 días" 
              icon="speed"
            />
          </Frame>
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de característica clave
function KeyFeature({ text, icon }) {
  return (
    <Frame
      name={`KeyFeature-${icon}`}
      background="transparent"
      width="100%"
      height="auto"
      style={{
        display: "flex",
        alignItems: "center",
        gap: "15px"
      }}
      whileHover={{ x: 5 }}
    >
      <Frame
        name="FeatureIcon"
        background={colors.primaryButton}
        width={36}
        height={36}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          flexShrink: 0
        }}
      >
        <Frame
          name="Icon"
          background="transparent"
          width={20}
          height={20}
          style={{
            backgroundImage: `url('/icons/${icon}.svg')`,
            backgroundSize: "contain",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat"
          }}
        />
      </Frame>
      <Frame
        name="FeatureText"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "16px",
          color: colors.primaryText
        }}
      >
        {text}
      </Frame>
    </Frame>
  )
}

export default AboutSection
