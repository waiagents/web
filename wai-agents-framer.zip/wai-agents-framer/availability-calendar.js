// availability-calendar.js - Componente de calendario de disponibilidad para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca (importados del archivo principal)
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal del Calendario de Disponibilidad
export function AvailabilityCalendar() {
  // Estado para el mes actual (0-11)
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth())
  // Estado para el año actual
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear())
  // Estado para la fecha seleccionada
  const [selectedDate, setSelectedDate] = useState(null)
  // Estado para la hora seleccionada
  const [selectedTime, setSelectedTime] = useState(null)
  // Estado para la disponibilidad de cupos
  const [availabilityData, setAvailabilityData] = useState({})
  
  // Efecto para cargar datos de disponibilidad al cambiar el mes
  useEffect(() => {
    // En un caso real, esto sería una llamada a API
    // Simulamos la carga de datos de disponibilidad para el mes actual
    generateMonthAvailability(currentMonth, currentYear)
  }, [currentMonth, currentYear])
  
  // Función para generar datos de disponibilidad simulados para todo el mes
  const generateMonthAvailability = (month, year) => {
    const daysInMonth = getDaysInMonth(month, year)
    const data = {}
    
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day)
      // No generamos disponibilidad para fechas pasadas
      if (date < new Date(new Date().setHours(0, 0, 0, 0))) {
        data[day] = { available: false, slots: [] }
        continue
      }
      
      // Generamos disponibilidad basada en el día de la semana
      const dayOfWeek = date.getDay()
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6
      
      // Simulamos que hay 15 cupos disponibles por día (menos en fin de semana)
      const totalSlots = isWeekend ? 8 : 15
      const availableHours = []
      
      // Distribuimos los slots disponibles a lo largo del día (9am a 5pm)
      const startHour = 9
      const endHour = 17
      
      for (let i = 0; i < totalSlots; i++) {
        const hour = startHour + Math.floor(i * (endHour - startHour) / totalSlots)
        const minute = Math.floor((i * (endHour - startHour) / totalSlots) % 1 * 60)
        availableHours.push(`${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`)
      }
      
      data[day] = {
        available: true,
        slots: availableHours,
        totalSlots: totalSlots,
        remainingSlots: totalSlots // En un caso real, esto vendría de la base de datos
      }
    }
    
    setAvailabilityData(data)
  }
  
  // Función para obtener los días del mes actual
  const getDaysInMonth = (month, year) => {
    return new Date(year, month + 1, 0).getDate()
  }
  
  // Función para obtener el primer día de la semana del mes (0-6)
  const getFirstDayOfMonth = (month, year) => {
    return new Date(year, month, 1).getDay()
  }
  
  // Función para ir al mes anterior
  const goToPreviousMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11)
      setCurrentYear(currentYear - 1)
    } else {
      setCurrentMonth(currentMonth - 1)
    }
    setSelectedDate(null)
    setSelectedTime(null)
  }
  
  // Función para ir al mes siguiente
  const goToNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0)
      setCurrentYear(currentYear + 1)
    } else {
      setCurrentMonth(currentMonth + 1)
    }
    setSelectedDate(null)
    setSelectedTime(null)
  }
  
  // Función para formatear fecha en formato legible
  const formatDate = (date) => {
    const options = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }
    return date.toLocaleDateString('es-ES', options)
  }
  
  // Nombres de los meses
  const monthNames = [
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
  ]
  
  // Nombres de los días de la semana
  const dayNames = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"]
  
  // Número de días en el mes actual
  const daysInMonth = getDaysInMonth(currentMonth, currentYear)
  // Primer día de la semana del mes (0-6)
  const firstDayOfMonth = getFirstDayOfMonth(currentMonth, currentYear)
  
  // Generamos los días del calendario
  const calendarDays = []
  
  // Días vacíos al inicio
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarDays.push(null)
  }
  
  // Días del mes
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(i)
  }
  
  // Función para manejar la selección de fecha
  const handleDateSelection = (day) => {
    const date = new Date(currentYear, currentMonth, day)
    const today = new Date()
    const isPast = date < new Date(today.setHours(0, 0, 0, 0))
    
    if (!isPast && availabilityData[day]?.available) {
      setSelectedDate(date)
      setSelectedTime(null) // Reset selected time when date changes
    }
  }
  
  // Función para manejar la selección de hora
  const handleTimeSelection = (time) => {
    setSelectedTime(time)
  }
  
  // Función para manejar la reserva
  const handleBooking = () => {
    if (selectedDate && selectedTime) {
      // En un caso real, aquí se enviaría la información a un backend
      alert(`Reserva confirmada para el ${formatDate(selectedDate)} a las ${selectedTime}`)
      
      // Actualizar la disponibilidad (simulado)
      const day = selectedDate.getDate()
      const updatedAvailability = { ...availabilityData }
      updatedAvailability[day].remainingSlots -= 1
      
      // Si no quedan slots, marcar como no disponible
      if (updatedAvailability[day].remainingSlots <= 0) {
        updatedAvailability[day].available = false
      }
      
      setAvailabilityData(updatedAvailability)
      
      // Reset selección
      setSelectedDate(null)
      setSelectedTime(null)
    }
  }
  
  return (
    <Frame
      name="AvailabilityCalendarSection"
      id="availability"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center"
        }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        Reserva tu Demo
      </Frame>
      
      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px"
        }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        Selecciona una fecha y hora disponible para tu demostración de 4 días por solo $35
      </Frame>
      
      <Frame
        name="CalendarContainer"
        background="white"
        width="100%"
        height="auto"
        radius={20}
        style={{
          display: "flex",
          flexDirection: "column",
          maxWidth: "1000px",
          boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)",
          overflow: "hidden"
        }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.4 }}
      >
        {/* Cabecera del calendario */}
        <Frame
          name="CalendarHeader"
          background={{
            type: "gradient",
            gradient: {
              angle: 135,
              stops: [
                { position: 0, color: colors.gradientStart },
                { position: 100, color: colors.gradientEnd }
              ]
            }
          }}
          width="100%"
          height="auto"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "20px 30px",
            color: "white"
          }}
        >
          <Frame
            name="PreviousMonth"
            background="transparent"
            width={40}
            height={40}
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              cursor: "pointer",
              borderRadius: "50%",
              transition: "background 0.3s ease"
            }}
            whileHover={{
              background: "rgba(255, 255, 255, 0.2)"
            }}
            onClick={goToPreviousMonth}
          >
            <span style={{ fontSize: "24px" }}>←</span>
          </Frame>
          
          <Frame
            name="CurrentMonth"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "24px",
              fontWeight: 600
            }}
          >
            {monthNames[currentMonth]} {currentYear}
          </Frame>
          
          <Frame
            name="NextMonth"
            background="transparent"
            width={40}
            height={40}
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              cursor: "pointer",
              borderRadius: "50%",
              transition: "background 0.3s ease"
            }}
            whileHover={{
              background: "rgba(255, 255, 255, 0.2)"
            }}
            onClick={goToNextMonth}
          >
            <span style={{ fontSize: "24px" }}>→</span>
          </Frame>
        </Frame>
        
        {/* Leyenda de disponibilidad */}
        <Frame
          name="AvailabilityLegend"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "20px",
            padding: "15px 0",
            borderBottom: "1px solid #eee"
          }}
        >
          <Frame
            name="FullAvailability"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "14px"
            }}
          >
            <Frame
              background="#4CAF50"
              width={12}
              height={12}
              radius="50%"
            />
            <span>Disponibilidad completa (15 cupos)</span>
          </Frame>
          
          <Frame
            name="LimitedAvailability"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "14px"
            }}
          >
            <Frame
              background="#FFC107"
              width={12}
              height={12}
              radius="50%"
            />
            <span>Disponibilidad limitada (&lt;8 cupos)</span>
          </Frame>
          
          <Frame
            name="NoAvailability"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              fontSize: "14px"
            }}
          >
            <Frame
              background="#F44336"
              width={12}
              height={12}
              radius="50%"
            />
            <span>No disponible</span>
          </Frame>
        </Frame>
        
        {/* Días de la semana */}
        <Frame
          name="WeekdaysHeader"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(7, 1fr)",
            padding: "15px 0",
            borderBottom: "1px solid #eee"
          }}
        >
          {dayNames.map((day, index) => (
            <Frame
              key={index}
              name={`Weekday-${day}`}
              background="transparent"
              width="100%"
              height="auto"
              style={{
                textAlign: "center",
                fontSize: "14px",
                fontWeight: 600,
                color: index === 0 || index === 6 ? "#FF5A5A" : colors.secondaryText
              }}
            >
              {day}
            </Frame>
          ))}
        </Frame>
        
        {/* Días del mes */}
        <Frame
          name="CalendarGrid"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(7, 1fr)",
            gap: "5px",
            padding: "15px"
          }}
        >
          {calendarDays.map((day, index) => {
            if (day === null) {
              return (
                <Frame
                  key={index}
                  name={`EmptyDay-${index}`}
                  background="transparent"
                  width="100%"
                  height={60}
                />
              )
            }
            
            const date = new Date(currentYear, currentMonth, day)
            const today = new Date()
            const isToday = date.toDateString() === today.toDateString()
            const isPast = date < new Date(today.setHours(0, 0, 0, 0))
            const isSelected = selectedDate && date.toDateString() === selectedDate.toDateString()
            
            // Obtenemos la disponibilidad del día
            const dayAvailability = availabilityData[day] || { available: false, slots: [], remainingSlots: 0 }
            const { available, remainingSlots } = dayAvailability
            
            // Determinamos el color de disponibilidad
            let availabilityColor = "#F44336" // Rojo (no disponible)
            if (available) {
              availabilityColor = remainingSlots > 8 ? "#4CAF50" : "#FFC107" // Verde o amarillo
            }
            
            return (
              <Frame
                key={index}
                name={`Day-${day}`}
                background={isSelected ? colors.primaryButton : isToday ? "rgba(124, 82, 237, 0.1)" : "transparent"}
                width="100%"
                height={60}
                radius={10}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                  cursor: isPast || !available ? "default" : "pointer",
                  opacity: isPast ? 0.5 : 1,
                  transition: "all 0.3s ease",
                  position: "relative"
                }}
                whileHover={!isPast && available ? {
                  scale: 1.05,
                  background: isSelected ? colors.primaryButton : "rgba(124, 82, 237, 0.2)"
                } : {}}
                onClick={() => {
                  if (!isPast && available) {
                    handleDateSelection(day)
                  }
                }}
              >
                {/* Indicador de disponibilidad */}
                {!isPast && (
                  <Frame
                    name={`AvailabilityDot-${day}`}
                    background={availabilityColor}
                    width={8}
                    height={8}
                    radius="50%"
                    style={{
                      position: "absolute",
                      top: "8px",
                      right: "8px"
                    }}
                  />
                )}
                
                <Frame
                  name={`DayNumber-${day}`}
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "16px",
                    fontWeight: isToday || isSelected ? 700 : 400,
                    color: isSelected ? "white" : colors.primaryText
                  }}
                >
                  {day}
                </Frame>
                
                {available && (
                  <Frame
                    name={`AvailabilityIndicator-${day}`}
                    background="transparent"
                    width="auto"
                    height="auto"
                    style={{
                      fontSize: "10px",
                      marginTop: "3px",
                      color: isSelected ? "rgba(255, 255, 255, 0.8)" : colors.secondaryText
                    }}
                  >
                    {remainingSlots} cupos
                  </Frame>
                )}
              </Frame>
            )
          })}
        </Frame>
        
        {/* Selección de hora si hay fecha seleccionada */}
        {selectedDate && (
          <Frame
            name="TimeSelection"
            background="#F8F9FB"
            width="100%"
            height="auto"
            style={{
              padding: "20px 30px",
              borderTop: "1px solid #eee"
            }}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.5 }}
          >
            <Frame
              name="TimeSelectionTitle"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "18px",
                fontWeight: 600,
                marginBottom: "15px",
                color: colors.primaryText
              }}
            >
              Horarios disponibles para el {formatDate(selectedDate)}:
            </Frame>
            
            <Frame
              name="TimeSlots"
              background="transparent"
              width="100%"
              height="auto"
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: "10px"
              }}
            >
              {availabilityData[selectedDate.getDate()]?.slots.map((time, index) => (
                <Frame
                  key={index}
                  name={`TimeSlot-${time}`}
                  background={selectedTime === time ? colors.primaryButton : "white"}
                  width="auto"
                  height="auto"
                  style={{
                    padding: "8px 15px",
                    borderRadius: "20px",
                    fontSize: "14px",
                    fontWeight: 500,
                    color: selectedTime === time ? "white" : colors.primaryText,
                    border: `1px solid ${selectedTime === time ? colors.primaryButton : "#ddd"}`,
                    cursor: "pointer",
                    transition: "all 0.3s ease"
                  }}
                  whileHover={{
                    scale: 1.05,
                    boxShadow: "0 5px 15px rgba(0, 0, 0, 0.1)"
                  }}
                  onClick={() => handleTimeSelection(time)}
                >
                  {time}
                </Frame>
              ))}
            </Frame>
            
            {selectedTime && (
              <Frame
                name="BookingButton"
                background={colors.primaryButton}
                width="100%"
                height="auto"
                style={{
                  padding: "15px",
                  borderRadius: "10px",
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "white",
                  textAlign: "center",
                  marginTop: "20px",
                  cursor: "pointer",
                  boxShadow: "0 10px 20px rgba(124, 82, 237, 0.3)",
                  transition: "all 0.3s ease"
                }}
                whileHover={{
                  scale: 1.02,
                  boxShadow: "0 15px 30px rgba(124, 82, 237, 0.4)"
                }}
                onClick={handleBooking}
              >
                Reservar Demo por $35
              </Frame>
            )}
          </Frame>
        )}
        
        {/* Información adicional */}
        <Frame
          name="AdditionalInfo"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            padding: "20px 30px",
            borderTop: "1px solid #eee",
            fontSize: "14px",
            color: colors.secondaryText,
            lineHeight: 1.6
          }}
        >
          <p>
            <strong>Información importante:</strong> La demo tiene una duración de 4 días consecutivos a partir de la fecha seleccionada. 
            Durante este período, tendrás acceso completo a todas las funcionalidades de automatización de WAI Agents para tu sector específico.
          </p>
          <p style={{ marginTop: "10px" }}>
            <strong>Política de cancelación:</strong> Puedes reprogramar tu demo hasta 24 horas antes de la fecha seleccionada sin costo adicional.
          </p>
        </Frame>
      </Frame>
    </Frame>
  )
}

export default AvailabilityCalendar
