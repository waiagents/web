// hero.js - Componente de hero section para WAI Agents

import { 
  Frame, 
  Stack, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect } from "react"

// Definición de colores de marca (importados del archivo principal)
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal del Hero
export function HeroSection() {
  // Animaciones para los elementos del hero
  const titleAnimation = useAnimation()
  const subtitleAnimation = useAnimation()
  const ctaAnimation = useAnimation()
  const particlesAnimation = useAnimation()
  
  // Efecto para iniciar las animaciones al cargar
  useEffect(() => {
    const sequence = async () => {
      await titleAnimation.start({ 
        opacity: 1, 
        y: 0,
        transition: { duration: 0.8 }
      })
      
      await subtitleAnimation.start({ 
        opacity: 1, 
        y: 0,
        transition: { duration: 0.8 }
      })
      
      await ctaAnimation.start({ 
        opacity: 1, 
        y: 0,
        scale: 1,
        transition: { duration: 0.8 }
      })
      
      await particlesAnimation.start({ 
        opacity: 1,
        transition: { duration: 1.5 }
      })
    }
    
    sequence()
  }, [])
  
  return (
    <Frame
      name="HeroSection"
      id="hero"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: colors.gradientStart },
            { position: 100, color: colors.gradientEnd }
          ]
        }
      }}
      width="100%"
      height="100vh"
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        padding: "0 5%",
        textAlign: "center",
        color: "white",
        position: "relative",
        overflow: "hidden"
      }}
    >
      {/* Partículas y elementos decorativos */}
      <Frame
        name="ParticlesContainer"
        background="transparent"
        width="100%"
        height="100%"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          zIndex: 1,
          opacity: 0
        }}
        animate={particlesAnimation}
      >
        {/* Círculos decorativos */}
        <Frame
          name="DecorativeCircle1"
          background="rgba(255, 255, 255, 0.1)"
          width={300}
          height={300}
          radius="50%"
          style={{
            position: "absolute",
            top: "-50px",
            right: "-100px"
          }}
          animate={{
            y: [0, -20, 0],
            x: [0, 10, 0]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
        
        <Frame
          name="DecorativeCircle2"
          background="rgba(255, 255, 255, 0.05)"
          width={500}
          height={500}
          radius="50%"
          style={{
            position: "absolute",
            bottom: "-200px",
            left: "-150px"
          }}
          animate={{
            y: [0, 30, 0],
            x: [0, -15, 0]
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
        
        {/* Partículas flotantes */}
        {Array.from({ length: 20 }).map((_, index) => (
          <Frame
            key={index}
            name={`Particle-${index}`}
            background="rgba(255, 255, 255, 0.2)"
            width={Math.random() * 10 + 2}
            height={Math.random() * 10 + 2}
            radius="50%"
            style={{
              position: "absolute",
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`
            }}
            animate={{
              y: [0, Math.random() * 100 - 50],
              x: [0, Math.random() * 100 - 50],
              opacity: [0.2, 0.8, 0.2]
            }}
            transition={{
              duration: Math.random() * 10 + 10,
              repeat: Infinity,
              repeatType: "reverse"
            }}
          />
        ))}
        
        {/* Líneas de conexión (simulando redes neuronales) */}
        {Array.from({ length: 5 }).map((_, index) => (
          <Frame
            key={index}
            name={`NeuralLine-${index}`}
            background="linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 50%, rgba(255,255,255,0) 100%)"
            width={Math.random() * 200 + 100}
            height={1}
            style={{
              position: "absolute",
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              transform: `rotate(${Math.random() * 360}deg)`
            }}
            animate={{
              opacity: [0.1, 0.5, 0.1],
              scale: [1, 1.2, 1]
            }}
            transition={{
              duration: Math.random() * 5 + 5,
              repeat: Infinity,
              repeatType: "reverse"
            }}
          />
        ))}
      </Frame>

      {/* Contenido principal */}
      <Frame
        name="HeroContent"
        background="transparent"
        width="100%"
        maxWidth={900}
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "30px",
          zIndex: 2
        }}
      >
        {/* Icono o símbolo de IA */}
        <Frame
          name="AIIcon"
          background="transparent"
          width={80}
          height={80}
          style={{
            marginBottom: "20px"
          }}
        >
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M40 10C23.4315 10 10 23.4315 10 40C10 56.5685 23.4315 70 40 70C56.5685 70 70 56.5685 70 40C70 23.4315 56.5685 10 40 10Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeDasharray="4 4"/>
            <path d="M40 20C29.0589 20 20 29.0589 20 40C20 50.9411 29.0589 60 40 60C50.9411 60 60 50.9411 60 40C60 29.0589 50.9411 20 40 20Z" fill="rgba(255,255,255,0.1)" stroke="white" strokeWidth="2"/>
            <path d="M40 30C34.4772 30 30 34.4772 30 40C30 45.5228 34.4772 50 40 50C45.5228 50 50 45.5228 50 40C50 34.4772 45.5228 30 40 30Z" fill="rgba(72,194,240,0.5)"/>
            <path d="M36 36L44 44M44 36L36 44" stroke="white" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </Frame>
        
        <Frame
          name="HeroTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "clamp(2.5rem, 5vw, 4rem)",
            fontWeight: 700,
            lineHeight: 1.2,
            opacity: 0,
            y: 20
          }}
          animate={titleAnimation}
        >
          Automatizamos TODO con Inteligencia Artificial
        </Frame>
        
        <Frame
          name="HeroSubtitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "clamp(1.2rem, 2vw, 1.5rem)",
            fontWeight: 400,
            maxWidth: "800px",
            lineHeight: 1.5,
            opacity: 0,
            y: 20
          }}
          animate={subtitleAnimation}
        >
          Con WAI Agents todo fluye solo, sin errores, sin excusas y sin estrés. Transformamos tu atención al cliente en una experiencia de alto nivel.
        </Frame>
        
        <Frame
          name="HeroCTA"
          background={colors.secondaryButton}
          width="auto"
          height="auto"
          style={{
            padding: "15px 40px",
            borderRadius: "30px",
            fontSize: "18px",
            fontWeight: 600,
            cursor: "pointer",
            boxShadow: "0 10px 20px rgba(72, 194, 240, 0.3)",
            transition: "transform 0.3s ease, box-shadow 0.3s ease",
            opacity: 0,
            y: 20,
            scale: 0.9
          }}
          whileHover={{ 
            scale: 1.05,
            boxShadow: "0 15px 30px rgba(72, 194, 240, 0.4)"
          }}
          animate={ctaAnimation}
          onClick={() => window.location.href = "#availability"}
        >
          Prueba nuestra demo por $35
        </Frame>
        
        {/* Indicador de scroll */}
        <Frame
          name="ScrollIndicator"
          background="transparent"
          width={30}
          height={50}
          style={{
            position: "absolute",
            bottom: "30px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "10px",
            opacity: 0
          }}
          animate={{
            opacity: [0, 1],
            y: [0, 10, 0]
          }}
          transition={{
            delay: 2,
            duration: 2,
            repeat: Infinity,
            repeatType: "loop"
          }}
        >
          <span style={{ fontSize: "12px", letterSpacing: "1px" }}>SCROLL</span>
          <svg width="20" height="30" viewBox="0 0 20 30" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="1" y="1" width="18" height="28" rx="9" stroke="white" strokeWidth="2"/>
            <circle cx="10" cy="10" r="4" fill="white">
              <animate
                attributeName="cy"
                values="10;16;10"
                dur="1.5s"
                repeatCount="indefinite"
              />
            </circle>
          </svg>
        </Frame>
      </Frame>
      
      {/* Overlay de gradiente para mejorar legibilidad */}
      <Frame
        name="GradientOverlay"
        background="linear-gradient(to bottom, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0) 100%)"
        width="100%"
        height="100%"
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          zIndex: 1
        }}
      />
    </Frame>
  )
}

// Componente de Typing Text Animation
function TypingText({ text, delay = 0 }) {
  const [displayText, setDisplayText] = useState("")
  const [currentIndex, setCurrentIndex] = useState(0)
  
  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayText(prev => prev + text[currentIndex])
        setCurrentIndex(prev => prev + 1)
      }, 100) // velocidad de escritura
      
      return () => clearTimeout(timeout)
    }
  }, [currentIndex, text])
  
  useEffect(() => {
    const timeout = setTimeout(() => {
      setCurrentIndex(0)
      setDisplayText("")
    }, delay)
    
    return () => clearTimeout(timeout)
  }, [delay])
  
  return (
    <span>{displayText}<span style={{ opacity: currentIndex < text.length ? 1 : 0 }}>|</span></span>
  )
}

export default HeroSection
