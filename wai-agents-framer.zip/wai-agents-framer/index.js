// index.js - Archivo principal para el sitio web de WAI Agents en Framer

// Importaciones de Framer
import { 
  Frame, 
  Page, 
  Stack, 
  Scroll, 
  useAnimation, 
  useMotionValue, 
  useTransform, 
  animate, 
  motion 
} from "framer"

// Definición de colores de marca
const colors = {
  background: "#F2F5F9",
  primaryButton: "#7C52ED",
  secondaryButton: "#48C2F0",
  primaryText: "#000000",
  secondaryText: "#1A6DB0",
  gradientStart: "#3D157E",
  gradientEnd: "#06185F"
}

// Componente principal de la aplicación
export default function WAIAgentsWebsite() {
  return (
    <Page 
      name="WAI Agents Website"
      background={colors.background}
      style={{
        fontFamily: "Inter, sans-serif",
        color: colors.primaryText,
        width: "100%",
        overflowX: "hidden"
      }}
    >
      {/* Componentes principales del sitio */}
      <Header />
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <AvailabilityCalendar />
      <TestimonialsSection />
      <ProcessSection />
      <BlogSection />
      <ContactSection />
      <Footer />
    </Page>
  )
}

// Componente de Header
function Header() {
  return (
    <Frame
      name="Header"
      background="transparent"
      width="100%"
      height={80}
      position="fixed"
      top={0}
      left={0}
      right={0}
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "0 5%",
        zIndex: 100,
        backdropFilter: "blur(10px)",
        backgroundColor: "rgba(242, 245, 249, 0.8)"
      }}
    >
      {/* Logo */}
      <Frame
        name="Logo"
        background="transparent"
        width={150}
        height={50}
        style={{
          display: "flex",
          alignItems: "center"
        }}
      >
        <img src="/logo.png" alt="WAI Agents Logo" style={{ height: "100%" }} />
      </Frame>

      {/* Menú de navegación */}
      <Frame
        name="Navigation"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          display: "flex",
          gap: "30px"
        }}
      >
        <NavItem text="Inicio" href="#hero" />
        <NavItem text="Nosotros" href="#about" />
        <NavItem text="Servicios" href="#services" />
        <NavItem text="Disponibilidad" href="#availability" />
        <NavItem text="Testimonios" href="#testimonials" />
        <NavItem text="Proceso" href="#process" />
        <NavItem text="Blog" href="#blog" />
        <NavItem text="Contacto" href="#contact" />
      </Frame>

      {/* Botón de menú móvil */}
      <Frame
        name="MobileMenuButton"
        background="transparent"
        width={40}
        height={40}
        style={{
          display: "none",
          flexDirection: "column",
          justifyContent: "space-around",
          cursor: "pointer",
          "@media (max-width: 768px)": {
            display: "flex"
          }
        }}
      >
        <Frame background={colors.primaryText} width={40} height={2} />
        <Frame background={colors.primaryText} width={40} height={2} />
        <Frame background={colors.primaryText} width={40} height={2} />
      </Frame>
    </Frame>
  )
}

// Componente de ítem de navegación
function NavItem({ text, href }) {
  return (
    <Frame
      name={`NavItem-${text}`}
      background="transparent"
      width="auto"
      height="auto"
      style={{
        fontSize: "16px",
        fontWeight: 500,
        color: colors.primaryText,
        cursor: "pointer",
        transition: "color 0.3s ease",
        ":hover": {
          color: colors.primaryButton
        },
        "@media (max-width: 768px)": {
          display: "none"
        }
      }}
      whileHover={{ scale: 1.05 }}
      onClick={() => window.location.href = href}
    >
      {text}
    </Frame>
  )
}

// Componente de Hero Section
function HeroSection() {
  return (
    <Frame
      name="HeroSection"
      id="hero"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: colors.gradientStart },
            { position: 100, color: colors.gradientEnd }
          ]
        }
      }}
      width="100%"
      height="100vh"
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        padding: "0 5%",
        textAlign: "center",
        color: "white",
        position: "relative",
        overflow: "hidden"
      }}
    >
      {/* Elementos decorativos */}
      <Frame
        name="DecorativeCircle1"
        background="rgba(255, 255, 255, 0.1)"
        width={300}
        height={300}
        radius="50%"
        style={{
          position: "absolute",
          top: "-50px",
          right: "-100px",
          zIndex: 1
        }}
      />
      <Frame
        name="DecorativeCircle2"
        background="rgba(255, 255, 255, 0.05)"
        width={500}
        height={500}
        radius="50%"
        style={{
          position: "absolute",
          bottom: "-200px",
          left: "-150px",
          zIndex: 1
        }}
      />

      {/* Contenido principal */}
      <Frame
        name="HeroContent"
        background="transparent"
        width="100%"
        maxWidth={900}
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "30px",
          zIndex: 2
        }}
      >
        <Frame
          name="HeroTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "clamp(2.5rem, 5vw, 4rem)",
            fontWeight: 700,
            lineHeight: 1.2
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          Automatizamos TODO con Inteligencia Artificial
        </Frame>
        <Frame
          name="HeroSubtitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "clamp(1.2rem, 2vw, 1.5rem)",
            fontWeight: 400,
            maxWidth: "800px",
            lineHeight: 1.5
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          Con WAI Agents todo fluye solo, sin errores, sin excusas y sin estrés. Transformamos tu atención al cliente en una experiencia de alto nivel.
        </Frame>
        <Frame
          name="HeroCTA"
          background={colors.secondaryButton}
          width="auto"
          height="auto"
          style={{
            padding: "15px 40px",
            borderRadius: "30px",
            fontSize: "18px",
            fontWeight: 600,
            cursor: "pointer",
            boxShadow: "0 10px 20px rgba(72, 194, 240, 0.3)",
            transition: "transform 0.3s ease, box-shadow 0.3s ease"
          }}
          whileHover={{ 
            scale: 1.05,
            boxShadow: "0 15px 30px rgba(72, 194, 240, 0.4)"
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          onClick={() => window.location.href = "#availability"}
        >
          Prueba nuestra demo por $35
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de About Section
function AboutSection() {
  return (
    <Frame
      name="AboutSection"
      id="about"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "50px",
          textAlign: "center"
        }}
      >
        Sobre WAI Agents
      </Frame>

      <Frame
        name="AboutContent"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          gap: "50px",
          maxWidth: "1200px",
          "@media (max-width: 992px)": {
            flexDirection: "column"
          }
        }}
      >
        {/* Imagen o gráfico */}
        <Frame
          name="AboutImage"
          background={{
            type: "gradient",
            gradient: {
              angle: 135,
              stops: [
                { position: 0, color: colors.primaryButton },
                { position: 100, color: colors.secondaryButton }
              ]
            }
          }}
          width="45%"
          height={400}
          radius={20}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            overflow: "hidden",
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)",
            "@media (max-width: 992px)": {
              width: "100%",
              height: 300
            }
          }}
        >
          <Frame
            name="AIGraphic"
            background="transparent"
            width="80%"
            height="80%"
            style={{
              backgroundImage: "url('/ai-graphic.svg')",
              backgroundSize: "contain",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat"
            }}
          />
        </Frame>

        {/* Texto descriptivo */}
        <Frame
          name="AboutText"
          background="transparent"
          width="45%"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "20px",
            "@media (max-width: 992px)": {
              width: "100%"
            }
          }}
        >
          <Frame
            name="AboutDescription"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              lineHeight: 1.6,
              color: colors.primaryText
            }}
          >
            WAI Agents es una empresa especializada en automatización de procesos mediante inteligencia artificial. Ofrecemos soluciones personalizadas para 12 sectores empresariales diferentes, transformando la manera en que las empresas gestionan su atención al cliente y sus operaciones diarias.
          </Frame>
          <Frame
            name="AboutDescription2"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              lineHeight: 1.6,
              color: colors.primaryText
            }}
          >
            Nuestra misión es simple: automatizar TODO. Con nuestros agentes inteligentes, garantizamos que todo fluya sin errores, sin excusas y sin estrés, permitiéndote enfocarte en lo que realmente importa para tu negocio.
          </Frame>
          <Frame
            name="AboutHighlight"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "20px",
              fontWeight: 600,
              color: colors.secondaryText,
              marginTop: "10px"
            }}
          >
            Se acabaron los pendientes. Con WAI Agents, la automatización inteligente está al alcance de tu mano.
          </Frame>
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Services Section
function ServicesSection() {
  return (
    <Frame
      name="ServicesSection"
      id="services"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: `${colors.background}` },
            { position: 100, color: "#E8EEF5" }
          ]
        }
      }}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center"
        }}
      >
        Nuestros Servicios
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px"
        }}
      >
        Soluciones de automatización personalizadas para 12 sectores empresariales
      </Frame>

      {/* Videos demostrativos */}
      <Frame
        name="VideosContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          flexWrap: "wrap",
          gap: "30px",
          marginBottom: "70px",
          maxWidth: "1200px"
        }}
      >
        <VideoDemo 
          title="Automatización para Clínicas" 
          embedId="placeholder1" 
          description="Gestión automatizada de citas, recordatorios y seguimiento de pacientes."
        />
        <VideoDemo 
          title="Automatización para Negocios" 
          embedId="placeholder2" 
          description="Atención al cliente 24/7 y gestión de consultas frecuentes."
        />
        <VideoDemo 
          title="Automatización para Ventas" 
          embedId="placeholder3" 
          description="Seguimiento de leads y proceso de ventas automatizado."
        />
      </Frame>

      {/* Servicios por sector */}
      <Frame
        name="SectorsGrid"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: "30px",
          maxWidth: "1200px"
        }}
      >
        <SectorCard 
          title="Sector Salud" 
          description="Automatización para clínicas médicas con gestión de citas y seguimiento de pacientes."
          icon="medical"
        />
        <SectorCard 
          title="Sector Belleza" 
          description="Automatización para peluquerías, spas y centros de belleza."
          icon="beauty"
        />
        <SectorCard 
          title="Sector Automotriz" 
          description="Automatización para rent car y talleres de mecánica."
          icon="automotive"
        />
        <SectorCard 
          title="Sector Inmobiliario" 
          description="Automatización para bienes raíces y gestión de propiedades."
          icon="realestate"
        />
        <SectorCard 
          title="Sector Legal" 
          description="Automatización para asesoría legal y fiscal."
          icon="legal"
        />
        <SectorCard 
          title="Sector Gastronómico" 
          description="Automatización para restaurantes y salones de eventos."
          icon="restaurant"
        />
        <SectorCard 
          title="Sector Educativo" 
          description="Automatización para centros educativos y academias."
          icon="education"
        />
        <SectorCard 
          title="Sector Turismo" 
          description="Automatización para agencias de viajes y excursiones."
          icon="travel"
        />
        <SectorCard 
          title="Sector Deportivo" 
          description="Automatización para gimnasios y clubes deportivos."
          icon="sports"
        />
        <SectorCard 
          title="Sector Veterinario" 
          description="Automatización para clínicas veterinarias y pet shops."
          icon="veterinary"
        />
        <SectorCard 
          title="Sector Espacios de Trabajo" 
          description="Automatización para coworkings y oficinas compartidas."
          icon="workspace"
        />
        <SectorCard 
          title="¿Tu sector?" 
          description="Contáctanos para una solución personalizada para tu industria."
          icon="custom"
          isHighlighted={true}
        />
      </Frame>
    </Frame>
  )
}

// Componente de Video Demostrativo
function VideoDemo({ title, embedId, description }) {
  return (
    <Frame
      name={`VideoDemo-${title}`}
      background="white"
      width="30%"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)",
        transition: "transform 0.3s ease, box-shadow 0.3s ease",
        minWidth: "300px",
        "@media (max-width: 992px)": {
          width: "100%",
          maxWidth: "500px"
        }
      }}
      whileHover={{
        scale: 1.02,
        boxShadow: "0 15px 40px rgba(0, 0, 0, 0.15)"
      }}
    >
      <Frame
        name="VideoContainer"
        background="#000"
        width="100%"
        height={0}
        style={{
          paddingBottom: "56.25%", // 16:9 aspect ratio
          position: "relative"
        }}
      >
        <iframe
          width="100%"
          height="100%"
          src={`https://www.youtube.com/embed/${embedId}`}
          title={title}
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%"
          }}
        />
      </Frame>
      <Frame
        name="VideoInfo"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          padding: "20px"
        }}
      >
        <Frame
          name="VideoTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "18px",
            fontWeight: 600,
            marginBottom: "10px",
            color: colors.primaryText
          }}
        >
          {title}
        </Frame>
        <Frame
          name="VideoDescription"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "14px",
            color: colors.secondaryText,
            lineHeight: 1.5
          }}
        >
          {description}
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Tarjeta de Sector
function SectorCard({ title, description, icon, isHighlighted = false }) {
  return (
    <Frame
      name={`SectorCard-${title}`}
      background={isHighlighted ? colors.primaryButton : "white"}
      width="100%"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        flexDirection: "column",
        padding: "30px",
        gap: "15px",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)",
        transition: "transform 0.3s ease, box-shadow 0.3s ease"
      }}
      whileHover={{
        scale: 1.03,
        boxShadow: "0 15px 40px rgba(0, 0, 0, 0.15)"
      }}
    >
      <Frame
        name="IconContainer"
        background={isHighlighted ? "rgba(255, 255, 255, 0.2)" : `rgba(${parseInt(colors.primaryButton.slice(1, 3), 16)}, ${parseInt(colors.primaryButton.slice(3, 5), 16)}, ${parseInt(colors.primaryButton.slice(5, 7), 16)}, 0.1)`}
        width={60}
        height={60}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
        <Frame
          name="Icon"
          background="transparent"
          width={30}
          height={30}
          style={{
            backgroundImage: `url('/icons/${icon}.svg')`,
            backgroundSize: "contain",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat"
          }}
        />
      </Frame>
      <Frame
        name="CardTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "18px",
          fontWeight: 600,
          color: isHighlighted ? "white" : colors.primaryText
        }}
      >
        {title}
      </Frame>
      <Frame
        name="CardDescription"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "14px",
          lineHeight: 1.5,
          color: isHighlighted ? "rgba(255, 255, 255, 0.9)" : colors.secondaryText
        }}
      >
        {description}
      </Frame>
    </Frame>
  )
}

// Componente de Calendario de Disponibilidad
function AvailabilityCalendar() {
  // Estado para el mes actual (0-11)
  const [currentMonth, setCurrentMonth] = React.useState(new Date().getMonth())
  // Estado para el año actual
  const [currentYear, setCurrentYear] = React.useState(new Date().getFullYear())
  // Estado para la fecha seleccionada
  const [selectedDate, setSelectedDate] = React.useState(null)
  // Estado para la hora seleccionada
  const [selectedTime, setSelectedTime] = React.useState(null)
  
  // Función para obtener los días del mes actual
  const getDaysInMonth = (month, year) => {
    return new Date(year, month + 1, 0).getDate()
  }
  
  // Función para obtener el primer día de la semana del mes (0-6)
  const getFirstDayOfMonth = (month, year) => {
    return new Date(year, month, 1).getDay()
  }
  
  // Simulación de disponibilidad (en un caso real, esto vendría de una API)
  const getAvailabilityForDate = (date) => {
    // Simulamos que hay 15 cupos disponibles por día
    // Excepto fines de semana que tienen menos disponibilidad
    const day = date.getDay()
    const isWeekend = day === 0 || day === 6
    
    // Generamos horas disponibles entre 9am y 5pm
    const availableHours = []
    const startHour = 9
    const endHour = 17
    const totalSlots = isWeekend ? 8 : 15 // Menos slots en fin de semana
    
    // Distribuimos los slots disponibles a lo largo del día
    for (let i = 0; i < totalSlots; i++) {
      const hour = startHour + Math.floor(i * (endHour - startHour) / totalSlots)
      const minute = (i * (endHour - startHour) / totalSlots) % 1 * 60
      availableHours.push(`${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`)
    }
    
    return {
      available: true,
      slots: availableHours
    }
  }
  
  // Función para ir al mes anterior
  const goToPreviousMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11)
      setCurrentYear(currentYear - 1)
    } else {
      setCurrentMonth(currentMonth - 1)
    }
  }
  
  // Función para ir al mes siguiente
  const goToNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0)
      setCurrentYear(currentYear + 1)
    } else {
      setCurrentMonth(currentMonth + 1)
    }
  }
  
  // Nombres de los meses
  const monthNames = [
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
  ]
  
  // Nombres de los días de la semana
  const dayNames = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"]
  
  // Número de días en el mes actual
  const daysInMonth = getDaysInMonth(currentMonth, currentYear)
  // Primer día de la semana del mes (0-6)
  const firstDayOfMonth = getFirstDayOfMonth(currentMonth, currentYear)
  
  // Generamos los días del calendario
  const calendarDays = []
  
  // Días vacíos al inicio
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarDays.push(null)
  }
  
  // Días del mes
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(i)
  }
  
  return (
    <Frame
      name="AvailabilityCalendarSection"
      id="availability"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center"
        }}
      >
        Reserva tu Demo
      </Frame>
      
      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px"
        }}
      >
        Selecciona una fecha y hora disponible para tu demostración de 4 días por solo $35
      </Frame>
      
      <Frame
        name="CalendarContainer"
        background="white"
        width="100%"
        height="auto"
        radius={20}
        style={{
          display: "flex",
          flexDirection: "column",
          maxWidth: "1000px",
          boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)",
          overflow: "hidden"
        }}
      >
        {/* Cabecera del calendario */}
        <Frame
          name="CalendarHeader"
          background={{
            type: "gradient",
            gradient: {
              angle: 135,
              stops: [
                { position: 0, color: colors.gradientStart },
                { position: 100, color: colors.gradientEnd }
              ]
            }
          }}
          width="100%"
          height="auto"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "20px 30px",
            color: "white"
          }}
        >
          <Frame
            name="PreviousMonth"
            background="transparent"
            width={40}
            height={40}
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              cursor: "pointer",
              borderRadius: "50%",
              transition: "background 0.3s ease"
            }}
            whileHover={{
              background: "rgba(255, 255, 255, 0.2)"
            }}
            onClick={goToPreviousMonth}
          >
            <span style={{ fontSize: "24px" }}>←</span>
          </Frame>
          
          <Frame
            name="CurrentMonth"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "24px",
              fontWeight: 600
            }}
          >
            {monthNames[currentMonth]} {currentYear}
          </Frame>
          
          <Frame
            name="NextMonth"
            background="transparent"
            width={40}
            height={40}
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              cursor: "pointer",
              borderRadius: "50%",
              transition: "background 0.3s ease"
            }}
            whileHover={{
              background: "rgba(255, 255, 255, 0.2)"
            }}
            onClick={goToNextMonth}
          >
            <span style={{ fontSize: "24px" }}>→</span>
          </Frame>
        </Frame>
        
        {/* Días de la semana */}
        <Frame
          name="WeekdaysHeader"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(7, 1fr)",
            padding: "15px 0",
            borderBottom: "1px solid #eee"
          }}
        >
          {dayNames.map((day, index) => (
            <Frame
              key={index}
              name={`Weekday-${day}`}
              background="transparent"
              width="100%"
              height="auto"
              style={{
                textAlign: "center",
                fontSize: "14px",
                fontWeight: 600,
                color: index === 0 || index === 6 ? "#FF5A5A" : colors.secondaryText
              }}
            >
              {day}
            </Frame>
          ))}
        </Frame>
        
        {/* Días del mes */}
        <Frame
          name="CalendarGrid"
          background="transparent"
          width="100%"
          height="auto"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(7, 1fr)",
            gap: "5px",
            padding: "15px"
          }}
        >
          {calendarDays.map((day, index) => {
            if (day === null) {
              return (
                <Frame
                  key={index}
                  name={`EmptyDay-${index}`}
                  background="transparent"
                  width="100%"
                  height={60}
                />
              )
            }
            
            const date = new Date(currentYear, currentMonth, day)
            const today = new Date()
            const isToday = date.toDateString() === today.toDateString()
            const isPast = date < new Date(today.setHours(0, 0, 0, 0))
            const isSelected = selectedDate && date.toDateString() === selectedDate.toDateString()
            
            // Simulamos disponibilidad
            const dayOfWeek = date.getDay()
            const hasAvailability = !isPast // Todos los días futuros tienen disponibilidad
            const availabilityCount = dayOfWeek === 0 || dayOfWeek === 6 ? 8 : 15 // Menos slots en fin de semana
            
            return (
              <Frame
                key={index}
                name={`Day-${day}`}
                background={isSelected ? colors.primaryButton : isToday ? "rgba(124, 82, 237, 0.1)" : "transparent"}
                width="100%"
                height={60}
                radius={10}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                  cursor: isPast ? "default" : "pointer",
                  opacity: isPast ? 0.5 : 1,
                  transition: "all 0.3s ease"
                }}
                whileHover={!isPast ? {
                  scale: 1.05,
                  background: isSelected ? colors.primaryButton : "rgba(124, 82, 237, 0.2)"
                } : {}}
                onClick={() => {
                  if (!isPast) {
                    setSelectedDate(date)
                    setSelectedTime(null) // Reset selected time when date changes
                  }
                }}
              >
                <Frame
                  name={`DayNumber-${day}`}
                  background="transparent"
                  width="auto"
                  height="auto"
                  style={{
                    fontSize: "16px",
                    fontWeight: isToday || isSelected ? 700 : 400,
                    color: isSelected ? "white" : colors.primaryText
                  }}
                >
                  {day}
                </Frame>
                
                {hasAvailability && (
                  <Frame
                    name={`AvailabilityIndicator-${day}`}
                    background="transparent"
                    width="auto"
                    height="auto"
                    style={{
                      fontSize: "10px",
                      marginTop: "3px",
                      color: isSelected ? "rgba(255, 255, 255, 0.8)" : colors.secondaryText
                    }}
                  >
                    {availabilityCount} cupos
                  </Frame>
                )}
              </Frame>
            )
          })}
        </Frame>
        
        {/* Selección de hora si hay fecha seleccionada */}
        {selectedDate && (
          <Frame
            name="TimeSelection"
            background="#F8F9FB"
            width="100%"
            height="auto"
            style={{
              padding: "20px 30px",
              borderTop: "1px solid #eee"
            }}
          >
            <Frame
              name="TimeSelectionTitle"
              background="transparent"
              width="auto"
              height="auto"
              style={{
                fontSize: "18px",
                fontWeight: 600,
                marginBottom: "15px",
                color: colors.primaryText
              }}
            >
              Horarios disponibles para el {selectedDate.getDate()} de {monthNames[selectedDate.getMonth()]}:
            </Frame>
            
            <Frame
              name="TimeSlots"
              background="transparent"
              width="100%"
              height="auto"
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: "10px"
              }}
            >
              {getAvailabilityForDate(selectedDate).slots.map((time, index) => (
                <Frame
                  key={index}
                  name={`TimeSlot-${time}`}
                  background={selectedTime === time ? colors.primaryButton : "white"}
                  width="auto"
                  height="auto"
                  style={{
                    padding: "8px 15px",
                    borderRadius: "20px",
                    fontSize: "14px",
                    fontWeight: 500,
                    color: selectedTime === time ? "white" : colors.primaryText,
                    border: `1px solid ${selectedTime === time ? colors.primaryButton : "#ddd"}`,
                    cursor: "pointer",
                    transition: "all 0.3s ease"
                  }}
                  whileHover={{
                    scale: 1.05,
                    boxShadow: "0 5px 15px rgba(0, 0, 0, 0.1)"
                  }}
                  onClick={() => setSelectedTime(time)}
                >
                  {time}
                </Frame>
              ))}
            </Frame>
            
            {selectedTime && (
              <Frame
                name="BookingButton"
                background={colors.primaryButton}
                width="100%"
                height="auto"
                style={{
                  padding: "15px",
                  borderRadius: "10px",
                  fontSize: "16px",
                  fontWeight: 600,
                  color: "white",
                  textAlign: "center",
                  marginTop: "20px",
                  cursor: "pointer",
                  boxShadow: "0 10px 20px rgba(124, 82, 237, 0.3)",
                  transition: "all 0.3s ease"
                }}
                whileHover={{
                  scale: 1.02,
                  boxShadow: "0 15px 30px rgba(124, 82, 237, 0.4)"
                }}
                onClick={() => window.location.href = "#contact"}
              >
                Reservar Demo por $35
              </Frame>
            )}
          </Frame>
        )}
      </Frame>
    </Frame>
  )
}

// Componente de Testimonials Section
function TestimonialsSection() {
  return (
    <Frame
      name="TestimonialsSection"
      id="testimonials"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: colors.gradientStart },
            { position: 100, color: colors.gradientEnd }
          ]
        }
      }}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative",
        color: "white"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          marginBottom: "20px",
          textAlign: "center"
        }}
      >
        Casos de Éxito
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px",
          opacity: 0.9
        }}
      >
        Descubre cómo WAI Agents ha transformado la atención al cliente de empresas en diferentes sectores
      </Frame>

      {/* Métricas de resultados */}
      <Frame
        name="MetricsContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          gap: "30px",
          marginBottom: "70px",
          maxWidth: "1200px"
        }}
      >
        <MetricCard 
          value="85%" 
          label="Reducción en tiempo de respuesta" 
          icon="clock"
        />
        <MetricCard 
          value="24/7" 
          label="Disponibilidad para clientes" 
          icon="calendar"
        />
        <MetricCard 
          value="95%" 
          label="Satisfacción de clientes" 
          icon="star"
        />
        <MetricCard 
          value="70%" 
          label="Reducción de costos operativos" 
          icon="dollar"
        />
      </Frame>

      {/* Testimonios */}
      <Frame
        name="TestimonialsContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "30px",
          maxWidth: "1000px"
        }}
      >
        <TestimonialCard 
          quote="WAI Agents transformó completamente la gestión de citas en nuestra clínica. Ahora nuestros pacientes pueden agendar 24/7 y reciben recordatorios automáticos, reduciendo las inasistencias en un 80%."
          author="Dr. Carlos Méndez"
          company="Clínica Médica Integral"
          sector="Sector Salud"
        />
        <TestimonialCard 
          quote="Desde que implementamos WAI Agents en nuestra agencia inmobiliaria, hemos podido atender el triple de consultas sin aumentar nuestro personal. El seguimiento automático de leads ha mejorado nuestras conversiones en un 45%."
          author="Laura Gutiérrez"
          company="Bienes Raíces Horizonte"
          sector="Sector Inmobiliario"
        />
        <TestimonialCard 
          quote="Como dueño de un restaurante, la automatización de reservas y pedidos ha sido un cambio radical. WAI Agents nos permite ofrecer una experiencia personalizada a cada cliente, recordando sus preferencias y ocasiones especiales."
          author="Miguel Ángel Torres"
          company="Restaurante La Terraza"
          sector="Sector Gastronómico"
        />
      </Frame>
    </Frame>
  )
}

// Componente de Tarjeta de Métrica
function MetricCard({ value, label, icon }) {
  return (
    <Frame
      name={`MetricCard-${label}`}
      background="rgba(255, 255, 255, 0.1)"
      width="250px"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "30px 20px",
        backdropFilter: "blur(10px)",
        border: "1px solid rgba(255, 255, 255, 0.2)",
        transition: "transform 0.3s ease"
      }}
      whileHover={{
        scale: 1.05
      }}
    >
      <Frame
        name="IconContainer"
        background="rgba(255, 255, 255, 0.2)"
        width={60}
        height={60}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          marginBottom: "15px"
        }}
      >
        <Frame
          name="Icon"
          background="transparent"
          width={30}
          height={30}
          style={{
            backgroundImage: `url('/icons/${icon}.svg')`,
            backgroundSize: "contain",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat"
          }}
        />
      </Frame>
      <Frame
        name="Value"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "36px",
          fontWeight: 700,
          marginBottom: "5px"
        }}
      >
        {value}
      </Frame>
      <Frame
        name="Label"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "16px",
          textAlign: "center",
          opacity: 0.9
        }}
      >
        {label}
      </Frame>
    </Frame>
  )
}

// Componente de Tarjeta de Testimonio
function TestimonialCard({ quote, author, company, sector }) {
  return (
    <Frame
      name={`TestimonialCard-${author}`}
      background="rgba(255, 255, 255, 0.1)"
      width="100%"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        flexDirection: "column",
        padding: "30px",
        backdropFilter: "blur(10px)",
        border: "1px solid rgba(255, 255, 255, 0.2)",
        transition: "transform 0.3s ease"
      }}
      whileHover={{
        scale: 1.02
      }}
    >
      <Frame
        name="QuoteIcon"
        background="transparent"
        width={40}
        height={40}
        style={{
          backgroundImage: "url('/icons/quote.svg')",
          backgroundSize: "contain",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          marginBottom: "15px",
          opacity: 0.7
        }}
      />
      <Frame
        name="QuoteText"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "18px",
          lineHeight: 1.6,
          marginBottom: "20px",
          fontStyle: "italic"
        }}
      >
        "{quote}"
      </Frame>
      <Frame
        name="AuthorInfo"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center"
        }}
      >
        <Frame
          name="AuthorDetails"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column"
          }}
        >
          <Frame
            name="AuthorName"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "16px",
              fontWeight: 600
            }}
          >
            {author}
          </Frame>
          <Frame
            name="AuthorCompany"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "14px",
              opacity: 0.9
            }}
          >
            {company}
          </Frame>
        </Frame>
        <Frame
          name="SectorTag"
          background="rgba(255, 255, 255, 0.2)"
          width="auto"
          height="auto"
          style={{
            padding: "5px 15px",
            borderRadius: "20px",
            fontSize: "12px",
            fontWeight: 500
          }}
        >
          {sector}
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Process Section
function ProcessSection() {
  return (
    <Frame
      name="ProcessSection"
      id="process"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center"
        }}
      >
        Nuestro Proceso
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "70px",
          textAlign: "center",
          maxWidth: "800px"
        }}
      >
        Implementamos soluciones de automatización en 4 simples pasos
      </Frame>

      {/* Pasos del proceso */}
      <Frame
        name="ProcessSteps"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "30px",
          maxWidth: "1000px"
        }}
      >
        <ProcessStep 
          number="01" 
          title="Demostración Inicial" 
          description="Prueba nuestro servicio durante 4 días por solo $35. Experimenta cómo la automatización puede transformar tu negocio sin compromiso a largo plazo."
        />
        <ProcessStep 
          number="02" 
          title="Análisis de Necesidades" 
          description="Nuestro equipo analiza los procesos específicos de tu negocio para identificar las áreas con mayor potencial de automatización y retorno de inversión."
        />
        <ProcessStep 
          number="03" 
          title="Implementación Personalizada" 
          description="Desarrollamos e implementamos soluciones de automatización adaptadas específicamente a tu sector y necesidades particulares."
        />
        <ProcessStep 
          number="04" 
          title="Soporte Continuo" 
          description="Proporcionamos soporte técnico, actualizaciones y optimizaciones continuas para asegurar que tu sistema de automatización evolucione con tu negocio."
        />
      </Frame>

      {/* CTA */}
      <Frame
        name="ProcessCTA"
        background={colors.primaryButton}
        width="auto"
        height="auto"
        style={{
          padding: "15px 40px",
          borderRadius: "30px",
          fontSize: "18px",
          fontWeight: 600,
          color: "white",
          marginTop: "50px",
          cursor: "pointer",
          boxShadow: "0 10px 20px rgba(124, 82, 237, 0.3)",
          transition: "transform 0.3s ease, box-shadow 0.3s ease"
        }}
        whileHover={{ 
          scale: 1.05,
          boxShadow: "0 15px 30px rgba(124, 82, 237, 0.4)"
        }}
        onClick={() => window.location.href = "#availability"}
      >
        Comienza con tu Demo
      </Frame>
    </Frame>
  )
}

// Componente de Paso del Proceso
function ProcessStep({ number, title, description }) {
  return (
    <Frame
      name={`ProcessStep-${number}`}
      background="white"
      width="100%"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        alignItems: "center",
        padding: "30px",
        gap: "30px",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)",
        transition: "transform 0.3s ease, box-shadow 0.3s ease",
        "@media (max-width: 768px)": {
          flexDirection: "column",
          alignItems: "flex-start",
          gap: "20px"
        }
      }}
      whileHover={{
        scale: 1.02,
        boxShadow: "0 15px 40px rgba(0, 0, 0, 0.1)"
      }}
    >
      <Frame
        name="StepNumber"
        background={{
          type: "gradient",
          gradient: {
            angle: 135,
            stops: [
              { position: 0, color: colors.primaryButton },
              { position: 100, color: colors.secondaryButton }
            ]
          }
        }}
        width={80}
        height={80}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          fontSize: "24px",
          fontWeight: 700,
          color: "white",
          flexShrink: 0
        }}
      >
        {number}
      </Frame>
      <Frame
        name="StepContent"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "10px"
        }}
      >
        <Frame
          name="StepTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "20px",
            fontWeight: 600,
            color: colors.primaryText
          }}
        >
          {title}
        </Frame>
        <Frame
          name="StepDescription"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            lineHeight: 1.6,
            color: colors.secondaryText
          }}
        >
          {description}
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Blog Section
function BlogSection() {
  return (
    <Frame
      name="BlogSection"
      id="blog"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: `${colors.background}` },
            { position: 100, color: "#E8EEF5" }
          ]
        }
      }}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center"
        }}
      >
        Recursos y Blog
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px"
        }}
      >
        Descubre las últimas tendencias en automatización e inteligencia artificial
      </Frame>

      {/* Artículos del blog */}
      <Frame
        name="BlogPostsContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
          gap: "30px",
          maxWidth: "1200px"
        }}
      >
        <BlogPostCard 
          title="Cómo la IA está transformando la atención al cliente" 
          excerpt="Descubre las últimas innovaciones en automatización de atención al cliente y cómo están revolucionando la experiencia del usuario."
          category="Inteligencia Artificial"
          date="15 Abril, 2025"
        />
        <BlogPostCard 
          title="10 procesos que puedes automatizar hoy mismo" 
          excerpt="Una guía práctica sobre los procesos empresariales más comunes que pueden ser automatizados para mejorar la eficiencia operativa."
          category="Automatización"
          date="8 Abril, 2025"
        />
        <BlogPostCard 
          title="El futuro del trabajo: colaboración humano-IA" 
          excerpt="Análisis sobre cómo la colaboración entre humanos e inteligencia artificial está redefiniendo el panorama laboral en diversos sectores."
          category="Tendencias"
          date="1 Abril, 2025"
        />
      </Frame>

      {/* Botón para ver más */}
      <Frame
        name="ViewMoreButton"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          padding: "15px 40px",
          borderRadius: "30px",
          fontSize: "16px",
          fontWeight: 600,
          color: colors.primaryButton,
          marginTop: "40px",
          cursor: "pointer",
          border: `2px solid ${colors.primaryButton}`,
          transition: "all 0.3s ease"
        }}
        whileHover={{ 
          scale: 1.05,
          background: "rgba(124, 82, 237, 0.1)"
        }}
      >
        Ver Más Artículos
      </Frame>
    </Frame>
  )
}

// Componente de Tarjeta de Artículo de Blog
function BlogPostCard({ title, excerpt, category, date }) {
  return (
    <Frame
      name={`BlogPost-${title}`}
      background="white"
      width="100%"
      height="auto"
      radius={15}
      style={{
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.05)",
        transition: "transform 0.3s ease, box-shadow 0.3s ease"
      }}
      whileHover={{
        scale: 1.03,
        boxShadow: "0 15px 40px rgba(0, 0, 0, 0.1)"
      }}
    >
      <Frame
        name="PostImage"
        background={{
          type: "gradient",
          gradient: {
            angle: 135,
            stops: [
              { position: 0, color: colors.gradientStart },
              { position: 100, color: colors.gradientEnd }
            ]
          }
        }}
        width="100%"
        height={200}
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
        <Frame
          name="CategoryTag"
          background="rgba(255, 255, 255, 0.2)"
          width="auto"
          height="auto"
          style={{
            padding: "5px 15px",
            borderRadius: "20px",
            fontSize: "12px",
            fontWeight: 500,
            color: "white"
          }}
        >
          {category}
        </Frame>
      </Frame>
      <Frame
        name="PostContent"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          padding: "25px",
          display: "flex",
          flexDirection: "column",
          gap: "15px"
        }}
      >
        <Frame
          name="PostDate"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "14px",
            color: colors.secondaryText
          }}
        >
          {date}
        </Frame>
        <Frame
          name="PostTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "20px",
            fontWeight: 600,
            color: colors.primaryText,
            lineHeight: 1.3
          }}
        >
          {title}
        </Frame>
        <Frame
          name="PostExcerpt"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            lineHeight: 1.6,
            color: colors.secondaryText
          }}
        >
          {excerpt}
        </Frame>
        <Frame
          name="ReadMoreLink"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            fontWeight: 600,
            color: colors.primaryButton,
            marginTop: "10px",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: "5px"
          }}
          whileHover={{
            x: 5
          }}
        >
          Leer más
          <span style={{ fontSize: "20px" }}>→</span>
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Contact Section
function ContactSection() {
  return (
    <Frame
      name="ContactSection"
      id="contact"
      background={colors.background}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "100px 5%",
        position: "relative"
      }}
    >
      <Frame
        name="SectionTitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "clamp(2rem, 4vw, 3rem)",
          fontWeight: 700,
          color: colors.primaryText,
          marginBottom: "20px",
          textAlign: "center"
        }}
      >
        Contáctanos
      </Frame>

      <Frame
        name="SectionSubtitle"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          fontSize: "20px",
          color: colors.secondaryText,
          marginBottom: "50px",
          textAlign: "center",
          maxWidth: "800px"
        }}
      >
        ¿Listo para automatizar tu negocio? Estamos aquí para ayudarte
      </Frame>

      <Frame
        name="ContactContainer"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: "50px",
          maxWidth: "1200px",
          "@media (max-width: 992px)": {
            flexDirection: "column"
          }
        }}
      >
        {/* Información de contacto */}
        <Frame
          name="ContactInfo"
          background="transparent"
          width="40%"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "30px",
            "@media (max-width: 992px)": {
              width: "100%"
            }
          }}
        >
          <Frame
            name="ContactIntro"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              lineHeight: 1.6,
              color: colors.primaryText
            }}
          >
            Estamos disponibles para responder a todas tus preguntas sobre nuestros servicios de automatización. Contáctanos a través del formulario o utiliza cualquiera de nuestros canales de comunicación.
          </Frame>

          <Frame
            name="ContactMethods"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "20px"
            }}
          >
            <ContactMethod 
              icon="email" 
              title="Email" 
              detail="info@waiagents.com"
            />
            <ContactMethod 
              icon="phone" 
              title="Teléfono" 
              detail="+1 (555) 123-4567"
            />
            <ContactMethod 
              icon="location" 
              title="Ubicación" 
              detail="Ciudad de México, México"
            />
          </Frame>

          {/* Redes sociales */}
          <Frame
            name="SocialMedia"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              gap: "15px",
              marginTop: "10px"
            }}
          >
            <SocialIcon icon="facebook" />
            <SocialIcon icon="twitter" />
            <SocialIcon icon="instagram" />
            <SocialIcon icon="linkedin" />
          </Frame>
        </Frame>

        {/* Formulario de contacto */}
        <Frame
          name="ContactForm"
          background="white"
          width="55%"
          height="auto"
          radius={20}
          style={{
            padding: "40px",
            boxShadow: "0 20px 40px rgba(0, 0, 0, 0.1)",
            "@media (max-width: 992px)": {
              width: "100%"
            }
          }}
        >
          <form
            action="https://formspree.io/f/your-formspree-id"
            method="POST"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "20px"
            }}
          >
            <Frame
              name="FormFields"
              background="transparent"
              width="100%"
              height="auto"
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "20px"
              }}
            >
              <FormField 
                type="text" 
                name="name" 
                placeholder="Nombre completo" 
                required={true}
              />
              <FormField 
                type="email" 
                name="email" 
                placeholder="Correo electrónico" 
                required={true}
              />
              <FormField 
                type="tel" 
                name="phone" 
                placeholder="Teléfono (opcional)" 
                required={false}
              />
              <FormField 
                type="text" 
                name="company" 
                placeholder="Empresa" 
                required={true}
              />
              <FormField 
                type="select" 
                name="industry" 
                placeholder="Selecciona tu sector" 
                required={true}
                options={[
                  "Sector Salud",
                  "Sector Belleza",
                  "Sector Automotriz",
                  "Sector Inmobiliario",
                  "Sector Legal",
                  "Sector Gastronómico",
                  "Sector Educativo",
                  "Sector Turismo",
                  "Sector Deportivo",
                  "Sector Veterinario",
                  "Sector Espacios de Trabajo",
                  "Otro"
                ]}
              />
              <FormField 
                type="textarea" 
                name="message" 
                placeholder="¿Cómo podemos ayudarte?" 
                required={true}
              />
            </Frame>

            <Frame
              name="SubmitButton"
              background={colors.primaryButton}
              width="100%"
              height="auto"
              style={{
                padding: "15px",
                borderRadius: "10px",
                fontSize: "16px",
                fontWeight: 600,
                color: "white",
                textAlign: "center",
                marginTop: "10px",
                cursor: "pointer",
                border: "none",
                boxShadow: "0 10px 20px rgba(124, 82, 237, 0.3)",
                transition: "all 0.3s ease"
              }}
              whileHover={{
                scale: 1.02,
                boxShadow: "0 15px 30px rgba(124, 82, 237, 0.4)"
              }}
              as="button"
              type="submit"
            >
              Enviar Mensaje
            </Frame>
          </form>
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Método de Contacto
function ContactMethod({ icon, title, detail }) {
  return (
    <Frame
      name={`ContactMethod-${title}`}
      background="transparent"
      width="auto"
      height="auto"
      style={{
        display: "flex",
        alignItems: "center",
        gap: "15px"
      }}
    >
      <Frame
        name="MethodIcon"
        background={{
          type: "gradient",
          gradient: {
            angle: 135,
            stops: [
              { position: 0, color: colors.primaryButton },
              { position: 100, color: colors.secondaryButton }
            ]
          }
        }}
        width={50}
        height={50}
        radius="50%"
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
        <Frame
          name="Icon"
          background="transparent"
          width={25}
          height={25}
          style={{
            backgroundImage: `url('/icons/${icon}.svg')`,
            backgroundSize: "contain",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat"
          }}
        />
      </Frame>
      <Frame
        name="MethodInfo"
        background="transparent"
        width="auto"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column"
        }}
      >
        <Frame
          name="MethodTitle"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            fontWeight: 600,
            color: colors.primaryText
          }}
        >
          {title}
        </Frame>
        <Frame
          name="MethodDetail"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            fontSize: "16px",
            color: colors.secondaryText
          }}
        >
          {detail}
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Icono Social
function SocialIcon({ icon }) {
  return (
    <Frame
      name={`SocialIcon-${icon}`}
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: colors.primaryButton },
            { position: 100, color: colors.secondaryButton }
          ]
        }
      }}
      width={40}
      height={40}
      radius="50%"
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        cursor: "pointer",
        transition: "transform 0.3s ease"
      }}
      whileHover={{
        scale: 1.1
      }}
    >
      <Frame
        name="Icon"
        background="transparent"
        width={20}
        height={20}
        style={{
          backgroundImage: `url('/icons/${icon}.svg')`,
          backgroundSize: "contain",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat"
        }}
      />
    </Frame>
  )
}

// Componente de Campo de Formulario
function FormField({ type, name, placeholder, required, options = [] }) {
  if (type === "textarea") {
    return (
      <Frame
        name={`FormField-${name}`}
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column"
        }}
      >
        <textarea
          name={name}
          placeholder={placeholder}
          required={required}
          style={{
            width: "100%",
            height: "120px",
            padding: "15px",
            borderRadius: "10px",
            border: "1px solid #ddd",
            fontSize: "16px",
            fontFamily: "Inter, sans-serif",
            resize: "vertical"
          }}
        />
      </Frame>
    )
  } else if (type === "select") {
    return (
      <Frame
        name={`FormField-${name}`}
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column"
        }}
      >
        <select
          name={name}
          required={required}
          style={{
            width: "100%",
            padding: "15px",
            borderRadius: "10px",
            border: "1px solid #ddd",
            fontSize: "16px",
            fontFamily: "Inter, sans-serif",
            appearance: "none",
            backgroundImage: "url('/icons/arrow-down.svg')",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "right 15px center",
            backgroundSize: "15px"
          }}
        >
          <option value="" disabled selected>
            {placeholder}
          </option>
          {options.map((option, index) => (
            <option key={index} value={option}>
              {option}
            </option>
          ))}
        </select>
      </Frame>
    )
  } else {
    return (
      <Frame
        name={`FormField-${name}`}
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          flexDirection: "column"
        }}
      >
        <input
          type={type}
          name={name}
          placeholder={placeholder}
          required={required}
          style={{
            width: "100%",
            padding: "15px",
            borderRadius: "10px",
            border: "1px solid #ddd",
            fontSize: "16px",
            fontFamily: "Inter, sans-serif"
          }}
        />
      </Frame>
    )
  }
}

// Componente de Footer
function Footer() {
  return (
    <Frame
      name="Footer"
      background={{
        type: "gradient",
        gradient: {
          angle: 135,
          stops: [
            { position: 0, color: colors.gradientStart },
            { position: 100, color: colors.gradientEnd }
          ]
        }
      }}
      width="100%"
      height="auto"
      style={{
        display: "flex",
        flexDirection: "column",
        padding: "80px 5% 40px",
        color: "white"
      }}
    >
      <Frame
        name="FooterContent"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: "40px",
          marginBottom: "60px",
          maxWidth: "1200px",
          margin: "0 auto"
        }}
      >
        {/* Columna de información de la empresa */}
        <Frame
          name="CompanyInfo"
          background="transparent"
          width="300px"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "20px"
          }}
        >
          <Frame
            name="FooterLogo"
            background="transparent"
            width={180}
            height={60}
            style={{
              display: "flex",
              alignItems: "center"
            }}
          >
            <img src="/logo-white.png" alt="WAI Agents Logo" style={{ height: "100%" }} />
          </Frame>
          <Frame
            name="CompanyDescription"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "16px",
              lineHeight: 1.6,
              opacity: 0.9
            }}
          >
            WAI Agents es una empresa especializada en automatización de procesos mediante inteligencia artificial, transformando la atención al cliente en diversos sectores empresariales.
          </Frame>
          <Frame
            name="FooterSocialMedia"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              display: "flex",
              gap: "15px"
            }}
          >
            <SocialIcon icon="facebook" />
            <SocialIcon icon="twitter" />
            <SocialIcon icon="instagram" />
            <SocialIcon icon="linkedin" />
          </Frame>
        </Frame>

        {/* Columna de enlaces rápidos */}
        <Frame
          name="QuickLinks"
          background="transparent"
          width="200px"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "15px"
          }}
        >
          <Frame
            name="LinksTitle"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              fontWeight: 600,
              marginBottom: "10px"
            }}
          >
            Enlaces Rápidos
          </Frame>
          <FooterLink text="Inicio" href="#hero" />
          <FooterLink text="Nosotros" href="#about" />
          <FooterLink text="Servicios" href="#services" />
          <FooterLink text="Disponibilidad" href="#availability" />
          <FooterLink text="Testimonios" href="#testimonials" />
          <FooterLink text="Proceso" href="#process" />
          <FooterLink text="Blog" href="#blog" />
          <FooterLink text="Contacto" href="#contact" />
        </Frame>

        {/* Columna de sectores */}
        <Frame
          name="Sectors"
          background="transparent"
          width="200px"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "15px"
          }}
        >
          <Frame
            name="SectorsTitle"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              fontWeight: 600,
              marginBottom: "10px"
            }}
          >
            Sectores
          </Frame>
          <FooterLink text="Sector Salud" href="#services" />
          <FooterLink text="Sector Belleza" href="#services" />
          <FooterLink text="Sector Automotriz" href="#services" />
          <FooterLink text="Sector Inmobiliario" href="#services" />
          <FooterLink text="Sector Legal" href="#services" />
          <FooterLink text="Sector Gastronómico" href="#services" />
          <FooterLink text="Ver todos" href="#services" />
        </Frame>

        {/* Columna de contacto */}
        <Frame
          name="ContactInfo"
          background="transparent"
          width="300px"
          height="auto"
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "15px"
          }}
        >
          <Frame
            name="ContactTitle"
            background="transparent"
            width="auto"
            height="auto"
            style={{
              fontSize: "18px",
              fontWeight: 600,
              marginBottom: "10px"
            }}
          >
            Contacto
          </Frame>
          <FooterContactItem icon="email" text="info@waiagents.com" />
          <FooterContactItem icon="phone" text="+1 (555) 123-4567" />
          <FooterContactItem icon="location" text="Ciudad de México, México" />
          <Frame
            name="NewsletterSignup"
            background="rgba(255, 255, 255, 0.1)"
            width="100%"
            height="auto"
            radius={10}
            style={{
              display: "flex",
              marginTop: "10px",
              overflow: "hidden"
            }}
          >
            <input
              type="email"
              placeholder="Tu correo electrónico"
              style={{
                flex: 1,
                padding: "12px 15px",
                border: "none",
                background: "transparent",
                color: "white",
                fontSize: "14px"
              }}
            />
            <Frame
              name="SubscribeButton"
              background={colors.secondaryButton}
              width="auto"
              height="auto"
              style={{
                padding: "12px 15px",
                fontSize: "14px",
                fontWeight: 600,
                cursor: "pointer"
              }}
            >
              Suscribir
            </Frame>
          </Frame>
        </Frame>
      </Frame>

      {/* Línea divisoria */}
      <Frame
        name="Divider"
        background="rgba(255, 255, 255, 0.2)"
        width="100%"
        height={1}
        style={{
          margin: "0 auto",
          maxWidth: "1200px"
        }}
      />

      {/* Copyright */}
      <Frame
        name="Copyright"
        background="transparent"
        width="100%"
        height="auto"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "30px 0 0",
          maxWidth: "1200px",
          margin: "0 auto",
          flexWrap: "wrap",
          gap: "20px",
          fontSize: "14px",
          opacity: 0.8
        }}
      >
        <Frame
          name="CopyrightText"
          background="transparent"
          width="auto"
          height="auto"
        >
          © {new Date().getFullYear()} WAI Agents. Todos los derechos reservados.
        </Frame>
        <Frame
          name="LegalLinks"
          background="transparent"
          width="auto"
          height="auto"
          style={{
            display: "flex",
            gap: "20px"
          }}
        >
          <FooterLink text="Términos y Condiciones" href="#" />
          <FooterLink text="Política de Privacidad" href="#" />
          <FooterLink text="Cookies" href="#" />
        </Frame>
      </Frame>
    </Frame>
  )
}

// Componente de Enlace de Footer
function FooterLink({ text, href }) {
  return (
    <Frame
      name={`FooterLink-${text}`}
      background="transparent"
      width="auto"
      height="auto"
      style={{
        fontSize: "14px",
        opacity: 0.9,
        cursor: "pointer",
        transition: "opacity 0.3s ease, transform 0.3s ease"
      }}
      whileHover={{
        opacity: 1,
        x: 5
      }}
      onClick={() => window.location.href = href}
    >
      {text}
    </Frame>
  )
}

// Componente de Ítem de Contacto de Footer
function FooterContactItem({ icon, text }) {
  return (
    <Frame
      name={`FooterContactItem-${icon}`}
      background="transparent"
      width="auto"
      height="auto"
      style={{
        display: "flex",
        alignItems: "center",
        gap: "10px",
        fontSize: "14px",
        opacity: 0.9
      }}
    >
      <Frame
        name="ItemIcon"
        background="transparent"
        width={16}
        height={16}
        style={{
          backgroundImage: `url('/icons/${icon}-white.svg')`,
          backgroundSize: "contain",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat"
        }}
      />
      {text}
    </Frame>
  )
}
