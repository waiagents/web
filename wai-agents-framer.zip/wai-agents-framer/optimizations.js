// optimizations.js - Optimizaciones para el sitio web de WAI Agents en Framer

import { 
  Frame, 
  useAnimation, 
  motion,
  useMotionValue,
  useTransform,
  animate
} from "framer"
import React, { useState, useEffect, lazy, Suspense } from "react"

// Función para cargar imágenes de forma progresiva
export function ProgressiveImage({ src, placeholder, alt, ...props }) {
  const [imgSrc, setImgSrc] = useState(placeholder || "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB2aWV3Qm94PSIwIDAgMTAwIDEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgZmlsbD0iI2YyZjVmOSIvPjwvc3ZnPg==")
  const [isLoaded, setIsLoaded] = useState(false)
  
  useEffect(() => {
    const img = new Image()
    img.src = src
    img.onload = () => {
      setImgSrc(src)
      setIsLoaded(true)
    }
  }, [src])
  
  return (
    <Frame
      background="transparent"
      width="100%"
      height="100%"
      style={{
        position: "relative",
        overflow: "hidden",
        ...props.style
      }}
      {...props}
    >
      <img 
        src={imgSrc} 
        alt={alt} 
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
          transition: "opacity 0.5s, filter 0.5s",
          opacity: isLoaded ? 1 : 0.5,
          filter: isLoaded ? "none" : "blur(10px)"
        }}
      />
    </Frame>
  )
}

// Componente de carga diferida (Lazy Loading)
export function LazyComponent({ component: Component, fallback, ...props }) {
  return (
    <Suspense fallback={fallback || <LoadingPlaceholder />}>
      <Component {...props} />
    </Suspense>
  )
}

// Componente de placeholder de carga
export function LoadingPlaceholder({ height = 300, ...props }) {
  return (
    <Frame
      background="#f2f5f9"
      width="100%"
      height={height}
      radius={15}
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        ...props.style
      }}
      {...props}
    >
      <Frame
        name="LoadingSpinner"
        background="transparent"
        width={40}
        height={40}
        style={{
          border: "3px solid rgba(124, 82, 237, 0.1)",
          borderTop: "3px solid #7C52ED",
          borderRadius: "50%"
        }}
        animate={{
          rotate: 360
        }}
        transition={{
          duration: 1,
          repeat: Infinity,
          ease: "linear"
        }}
      />
    </Frame>
  )
}

// Hook para Intersection Observer (carga diferida basada en scroll)
export function useIntersectionObserver(options = {}) {
  const [ref, setRef] = useState(null)
  const [isIntersecting, setIsIntersecting] = useState(false)
  
  useEffect(() => {
    if (!ref) return
    
    const observer = new IntersectionObserver(([entry]) => {
      setIsIntersecting(entry.isIntersecting)
      
      // Si queremos observar solo una vez y dejar de observar después
      if (entry.isIntersecting && options.once) {
        observer.unobserve(ref)
      }
    }, options)
    
    observer.observe(ref)
    
    return () => {
      if (ref) {
        observer.unobserve(ref)
      }
    }
  }, [ref, options.once, options.rootMargin, options.threshold])
  
  return [setRef, isIntersecting]
}

// Componente de imagen con carga diferida
export function LazyImage({ src, alt, ...props }) {
  const [ref, isIntersecting] = useIntersectionObserver({ once: true, threshold: 0.1 })
  
  return (
    <Frame
      background="#f2f5f9"
      width="100%"
      height={props.height || 300}
      style={{
        overflow: "hidden",
        ...props.style
      }}
      ref={ref}
      {...props}
    >
      {isIntersecting ? (
        <ProgressiveImage 
          src={src} 
          alt={alt} 
          style={{
            width: "100%",
            height: "100%"
          }}
        />
      ) : null}
    </Frame>
  )
}

// Componente de video con carga diferida
export function LazyVideo({ src, poster, ...props }) {
  const [ref, isIntersecting] = useIntersectionObserver({ once: true, threshold: 0.1 })
  
  return (
    <Frame
      background="#f2f5f9"
      width="100%"
      height={props.height || 300}
      style={{
        overflow: "hidden",
        ...props.style
      }}
      ref={ref}
      {...props}
    >
      {isIntersecting ? (
        <video
          src={src}
          poster={poster}
          controls={props.controls}
          autoPlay={props.autoPlay}
          loop={props.loop}
          muted={props.muted}
          playsInline={props.playsInline}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover"
          }}
        />
      ) : (
        poster && (
          <img 
            src={poster} 
            alt="Video thumbnail" 
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover"
            }}
          />
        )
      )}
    </Frame>
  )
}

// Componente de iframe con carga diferida
export function LazyIframe({ src, title, ...props }) {
  const [ref, isIntersecting] = useIntersectionObserver({ once: true, threshold: 0.1 })
  
  return (
    <Frame
      background="#f2f5f9"
      width="100%"
      height={props.height || 300}
      style={{
        overflow: "hidden",
        ...props.style
      }}
      ref={ref}
      {...props}
    >
      {isIntersecting ? (
        <iframe
          src={src}
          title={title}
          frameBorder="0"
          style={{
            width: "100%",
            height: "100%",
            border: "none"
          }}
          loading="lazy"
          {...props}
        />
      ) : (
        <LoadingPlaceholder height="100%" />
      )}
    </Frame>
  )
}

// Componente de SEO
export function SEOHead({ title, description, keywords, ogImage, ogUrl, twitterCard }) {
  useEffect(() => {
    // Título de la página
    document.title = title || "WAI Agents - Automatizamos TODO con Inteligencia Artificial"
    
    // Meta descripción
    let metaDescription = document.querySelector('meta[name="description"]')
    if (!metaDescription) {
      metaDescription = document.createElement('meta')
      metaDescription.name = "description"
      document.head.appendChild(metaDescription)
    }
    metaDescription.content = description || "WAI Agents automatiza la atención al cliente y procesos empresariales con inteligencia artificial para 12 sectores diferentes."
    
    // Meta keywords
    let metaKeywords = document.querySelector('meta[name="keywords"]')
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta')
      metaKeywords.name = "keywords"
      document.head.appendChild(metaKeywords)
    }
    metaKeywords.content = keywords || "automatización, inteligencia artificial, atención al cliente, IA, agentes virtuales, chatbots, automatización de procesos"
    
    // Open Graph
    let ogTitle = document.querySelector('meta[property="og:title"]')
    if (!ogTitle) {
      ogTitle = document.createElement('meta')
      ogTitle.setAttribute('property', 'og:title')
      document.head.appendChild(ogTitle)
    }
    ogTitle.content = title || "WAI Agents - Automatizamos TODO con Inteligencia Artificial"
    
    let ogDesc = document.querySelector('meta[property="og:description"]')
    if (!ogDesc) {
      ogDesc = document.createElement('meta')
      ogDesc.setAttribute('property', 'og:description')
      document.head.appendChild(ogDesc)
    }
    ogDesc.content = description || "WAI Agents automatiza la atención al cliente y procesos empresariales con inteligencia artificial para 12 sectores diferentes."
    
    let ogImg = document.querySelector('meta[property="og:image"]')
    if (!ogImg) {
      ogImg = document.createElement('meta')
      ogImg.setAttribute('property', 'og:image')
      document.head.appendChild(ogImg)
    }
    ogImg.content = ogImage || "/og-image.jpg"
    
    let ogType = document.querySelector('meta[property="og:type"]')
    if (!ogType) {
      ogType = document.createElement('meta')
      ogType.setAttribute('property', 'og:type')
      document.head.appendChild(ogType)
    }
    ogType.content = "website"
    
    let ogUrl = document.querySelector('meta[property="og:url"]')
    if (!ogUrl) {
      ogUrl = document.createElement('meta')
      ogUrl.setAttribute('property', 'og:url')
      document.head.appendChild(ogUrl)
    }
    ogUrl.content = ogUrl || "https://waiagents.com"
    
    // Twitter Card
    let twitterCard = document.querySelector('meta[name="twitter:card"]')
    if (!twitterCard) {
      twitterCard = document.createElement('meta')
      twitterCard.name = "twitter:card"
      document.head.appendChild(twitterCard)
    }
    twitterCard.content = twitterCard || "summary_large_image"
    
    // Canonical URL
    let canonical = document.querySelector('link[rel="canonical"]')
    if (!canonical) {
      canonical = document.createElement('link')
      canonical.rel = "canonical"
      document.head.appendChild(canonical)
    }
    canonical.href = ogUrl || "https://waiagents.com"
    
    // Favicon
    let favicon = document.querySelector('link[rel="icon"]')
    if (!favicon) {
      favicon = document.createElement('link')
      favicon.rel = "icon"
      document.head.appendChild(favicon)
    }
    favicon.href = "/favicon.ico"
    
    // Preconnect para recursos externos
    const preconnectDomains = [
      "https://fonts.googleapis.com",
      "https://fonts.gstatic.com",
      "https://www.youtube.com",
      "https://img.youtube.com"
    ]
    
    preconnectDomains.forEach(domain => {
      let preconnect = document.querySelector(`link[rel="preconnect"][href="${domain}"]`)
      if (!preconnect) {
        preconnect = document.createElement('link')
        preconnect.rel = "preconnect"
        preconnect.href = domain
        document.head.appendChild(preconnect)
      }
    })
    
    // Preload de fuentes críticas
    let fontPreload = document.querySelector('link[rel="preload"][as="font"]')
    if (!fontPreload) {
      fontPreload = document.createElement('link')
      fontPreload.rel = "preload"
      fontPreload.as = "font"
      fontPreload.type = "font/woff2"
      fontPreload.href = "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
      fontPreload.crossOrigin = "anonymous"
      document.head.appendChild(fontPreload)
    }
    
  }, [title, description, keywords, ogImage, ogUrl, twitterCard])
  
  return null
}

// Componente de optimización de rendimiento
export function PerformanceOptimizer({ children }) {
  useEffect(() => {
    // Diferir scripts no críticos
    const deferScripts = () => {
      const scripts = document.querySelectorAll('script[defer]')
      scripts.forEach(script => {
        script.setAttribute('defer', '')
      })
    }
    
    // Cargar estilos críticos primero
    const loadCriticalCSS = () => {
      const criticalStyles = document.querySelectorAll('link[rel="stylesheet"][data-critical="true"]')
      criticalStyles.forEach(style => {
        style.setAttribute('media', 'all')
      })
    }
    
    // Optimizar imágenes
    const optimizeImages = () => {
      const images = document.querySelectorAll('img:not([loading])')
      images.forEach(img => {
        if (!img.hasAttribute('loading')) {
          img.setAttribute('loading', 'lazy')
        }
        
        if (!img.hasAttribute('decoding')) {
          img.setAttribute('decoding', 'async')
        }
      })
    }
    
    // Ejecutar optimizaciones
    deferScripts()
    loadCriticalCSS()
    optimizeImages()
    
    // Registrar Service Worker para caché
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js').catch(error => {
          console.log('Service Worker registration failed:', error)
        })
      })
    }
    
  }, [])
  
  return <>{children}</>
}

export default {
  ProgressiveImage,
  LazyComponent,
  LoadingPlaceholder,
  useIntersectionObserver,
  LazyImage,
  LazyVideo,
  LazyIframe,
  SEOHead,
  PerformanceOptimizer
}
